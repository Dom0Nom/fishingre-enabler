package com.minecraftmonitor;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.*;
import java.net.Socket;

public class IpcClient
{
    private final String host;
    private final int port;
    private final String instanceId;
    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    private boolean running;
    private boolean connected;
    private Thread listenerThread;
    private int reconnectAttempts;

    public IpcClient(String host, int port, String instanceId)
    {
        this.host = host;
        this.port = port;
        this.instanceId = instanceId;
    }

    public void start()
    {
        running = true;
        listenerThread = new Thread(this::connectionLoop);
        listenerThread.start();
    }

    public void stop()
    {
        running = false;
        disconnect();
    }

    public boolean isConnected()
    {
        return connected;
    }

    public void sendSequenceComplete()
    {
        JsonObject json = new JsonObject();
        json.addProperty("type", "sequenceComplete");
        json.addProperty("instanceId", instanceId);
        send(json.toString());
    }

    public void sendStatus(String state)
    {
        JsonObject json = new JsonObject();
        json.addProperty("type", "status");
        json.addProperty("instanceId", instanceId);
        json.addProperty("state", state);
        send(json.toString());
    }

    public void sendTestEvent()
    {
        JsonObject json = new JsonObject();
        json.addProperty("type", "testEvent");
        json.addProperty("instanceId", instanceId);
        send(json.toString());
    }

    private void send(String message)
    {
        if (!connected || writer == null)
            return;

        try
        {
            writer.println(message);
            writer.flush();
        }
        catch (Exception e)
        {
            disconnect();
        }
    }

    private void connectionLoop()
    {
        while (running)
        {
            try
            {
                if (!connected)
                {
                    connect();
                }

                if (connected && reader != null)
                {
                    String line = reader.readLine();
                    if (line != null)
                    {
                        handleMessage(line);
                    }
                    else
                    {
                        disconnect();
                    }
                }
            }
            catch (Exception e)
            {
                disconnect();
            }

            if (!connected)
            {
                try
                {
                    int delay = Math.min(30000, 1000 * (int)Math.pow(2, Math.min(reconnectAttempts, 5)));
                    Thread.sleep(delay);
                }
                catch (InterruptedException e)
                {
                    break;
                }
            }
        }
    }

    private void connect()
    {
        try
        {
            socket = new Socket(host, port);
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true);
            connected = true;
            reconnectAttempts = 0;

            sendStatus("connected");
        }
        catch (Exception e)
        {
            reconnectAttempts++;
            connected = false;
        }
    }

    private void disconnect()
    {
        connected = false;

        try
        {
            if (reader != null) reader.close();
            if (writer != null) writer.close();
            if (socket != null) socket.close();
        }
        catch (Exception e)
        {
            // Silent fail
        }

        reader = null;
        writer = null;
        socket = null;
    }

    private void handleMessage(String message)
    {
        try
        {
            JsonParser parser = new JsonParser();
            JsonObject json = parser.parse(message).getAsJsonObject();
            String type = json.get("type").getAsString();

            if ("runSpecialSequence".equals(type))
            {
                int afterHubSeconds = json.get("afterHubSeconds").getAsInt();
                int afterWarpSeconds = json.get("afterWarpSeconds").getAsInt();

                ModIntegration.commandExecutor.startSequence(afterHubSeconds, afterWarpSeconds);
            }
        }
        catch (Exception e)
        {
            // Silent fail
        }
    }
}
