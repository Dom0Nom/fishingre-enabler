package com.minecraftmonitor.gui;

import com.minecraftmonitor.ModIntegration;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import java.io.IOException;

public class GuiModConfig extends GuiScreen
{
    private GuiTextField instanceIdField;
    private GuiButton enabledButton;
    private GuiButton saveButton;
    private GuiButton testButton;
    private GuiButton doneButton;
    private boolean enabled;

    @Override
    public void initGui()
    {
        super.initGui();

        enabled = ModIntegration.config.enabled;

        int centerX = this.width / 2;
        int startY = this.height / 4;

        instanceIdField = new GuiTextField(0, this.fontRendererObj, centerX - 100, startY + 30, 200, 20);
        instanceIdField.setMaxStringLength(50);
        instanceIdField.setText(ModIntegration.config.instanceId);

        enabledButton = new GuiButton(1, centerX - 100, startY + 60, 200, 20,
            "Integration: " + (enabled ? "Enabled" : "Disabled"));

        saveButton = new GuiButton(2, centerX - 155, startY + 100, 100, 20, "Save");
        testButton = new GuiButton(3, centerX - 50, startY + 100, 100, 20, "Test Connection");
        doneButton = new GuiButton(4, centerX + 55, startY + 100, 100, 20, "Done");

        this.buttonList.add(enabledButton);
        this.buttonList.add(saveButton);
        this.buttonList.add(testButton);
        this.buttonList.add(doneButton);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException
    {
        if (button.id == 1)
        {
            enabled = !enabled;
            enabledButton.displayString = "Integration: " + (enabled ? "Enabled" : "Disabled");
        }
        else if (button.id == 2)
        {
            saveConfig();
        }
        else if (button.id == 3)
        {
            testConnection();
        }
        else if (button.id == 4)
        {
            this.mc.displayGuiScreen(null);
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException
    {
        super.keyTyped(typedChar, keyCode);
        instanceIdField.textboxKeyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException
    {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        instanceIdField.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void updateScreen()
    {
        super.updateScreen();
        instanceIdField.updateCursorCounter();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        this.drawDefaultBackground();

        int centerX = this.width / 2;
        int startY = this.height / 4;

        this.drawCenteredString(this.fontRendererObj, "Minecraft Monitor Integration", centerX, startY, 0xFFFFFF);
        this.drawString(this.fontRendererObj, "Instance ID:", centerX - 100, startY + 18, 0xAAAAAA);

        instanceIdField.drawTextBox();

        String status = ModIntegration.ipcClient != null && ModIntegration.ipcClient.isConnected()
            ? "Status: Connected"
            : "Status: Disconnected";
        this.drawCenteredString(this.fontRendererObj, status, centerX, startY + 140, 0xFFFFFF);

        String sequenceStatus = ModIntegration.commandExecutor != null && ModIntegration.commandExecutor.isRunning()
            ? "Sequence: Running"
            : "Sequence: Idle";
        this.drawCenteredString(this.fontRendererObj, sequenceStatus, centerX, startY + 155, 0xFFFFFF);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame()
    {
        return false;
    }

    private void saveConfig()
    {
        ModIntegration.config.instanceId = instanceIdField.getText();
        ModIntegration.config.enabled = enabled;
        ModIntegration.config.save();
    }

    private void testConnection()
    {
        if (ModIntegration.ipcClient != null)
        {
            ModIntegration.ipcClient.sendStatus("ping");
        }
    }
}
