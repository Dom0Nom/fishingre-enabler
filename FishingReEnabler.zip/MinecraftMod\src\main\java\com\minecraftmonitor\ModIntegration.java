package com.minecraftmonitor;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.ClientCommandHandler;
import org.lwjgl.input.Keyboard;

@Mod(modid = ModIntegration.MODID, version = ModIntegration.VERSION, clientSideOnly = true)
public class ModIntegration
{
    public static final String MODID = "minecraftmonitor";
    public static final String VERSION = "1.0";

    public static ModConfig config;
    public static IpcClient ipcClient;
    public static CommandExecutor commandExecutor;

    private static KeyBinding openGuiKey;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
        config = new ModConfig(event.getSuggestedConfigurationFile());
        config.load();
    }

    @EventHandler
    public void init(FMLInitializationEvent event)
    {
        openGuiKey = new KeyBinding("Open Mod Config", Keyboard.KEY_RSHIFT, "Minecraft Monitor");
        ClientRegistry.registerKeyBinding(openGuiKey);

        MinecraftForge.EVENT_BUS.register(this);

        commandExecutor = new CommandExecutor();

        ipcClient = new IpcClient(config.serverHost, config.serverPort, config.instanceId);
        ipcClient.start();

        // Register test command
        ClientCommandHandler.instance.registerCommand(new TestCommand());
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event)
    {
        if (openGuiKey.isPressed())
        {
            net.minecraft.client.Minecraft.getMinecraft().displayGuiScreen(
                new com.minecraftmonitor.gui.GuiModConfig()
            );
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event)
    {
        if (event.phase == TickEvent.Phase.END)
        {
            commandExecutor.tick();
        }
    }
}
