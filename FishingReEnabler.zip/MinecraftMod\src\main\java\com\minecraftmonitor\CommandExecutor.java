package com.minecraftmonitor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class CommandExecutor
{
    private boolean running;
    private int tickCounter;
    private int stage;
    private int afterHubTicks;
    private int afterWarpTicks;

    public void startSequence(int afterHubSeconds, int afterWarpSeconds)
    {
        if (running)
            return;

        EntityPlayerSP player = Minecraft.getMinecraft().thePlayer;
        if (player == null)
            return;

        running = true;
        tickCounter = 0;
        stage = 0;
        afterHubTicks = afterHubSeconds * 20;
        afterWarpTicks = afterWarpSeconds * 20;
    }

    public void tick()
    {
        if (!running)
            return;

        EntityPlayerSP player = Minecraft.getMinecraft().thePlayer;
        if (player == null)
        {
            running = false;
            return;
        }

        tickCounter++;

        if (stage == 0)
        {
            player.sendChatMessage("/hub");
            stage = 1;
            tickCounter = 0;
        }
        else if (stage == 1 && tickCounter >= afterHubTicks)
        {
            player.sendChatMessage("/warp BAYOU");
            stage = 2;
            tickCounter = 0;
        }
        else if (stage == 2 && tickCounter >= afterWarpTicks)
        {
            running = false;
            stage = 0;
            tickCounter = 0;

            if (ModIntegration.ipcClient != null)
            {
                ModIntegration.ipcClient.sendSequenceComplete();
            }
        }
    }

    public boolean isRunning()
    {
        return running;
    }
}
