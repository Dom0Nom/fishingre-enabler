package com.minecraftmonitor;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.fml.common.FMLLog;

public class TestCommand extends CommandBase
{
    @Override
    public String getCommandName()
    {
        return "mcmontest";
    }

    @Override
    public String getCommandUsage(ICommandSender sender)
    {
        return "/mcmontest - Trigger test event";
    }

    @Override
    public int getRequiredPermissionLevel()
    {
        return 0;
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) throws CommandException
    {
        // Write the event pattern to the log file to test detection
        FMLLog.info("§cFailed to find or reach a new hotspot after 5 attempts");
        sender.addChatMessage(new ChatComponentText("§a[Monitor] Test event written to log!"));
    }
}
