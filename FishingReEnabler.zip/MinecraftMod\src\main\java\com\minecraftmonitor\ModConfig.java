package com.minecraftmonitor;

import net.minecraftforge.common.config.Configuration;
import java.io.File;

public class ModConfig
{
    private Configuration config;

    public String instanceId;
    public boolean enabled;
    public String serverHost;
    public int serverPort;

    public ModConfig(File configFile)
    {
        config = new Configuration(configFile);
    }

    public void load()
    {
        config.load();

        instanceId = config.getString("instanceId", "general", "instance1", "Unique ID for this instance");
        enabled = config.getBoolean("enabled", "general", true, "Enable integration");
        serverHost = config.getString("serverHost", "general", "localhost", "Desktop app host");
        serverPort = config.getInt("serverPort", "general", 17653, 1, 65535, "Desktop app port");

        if (config.hasChanged())
        {
            config.save();
        }
    }

    public void save()
    {
        config.get("general", "instanceId", "instance1").set(instanceId);
        config.get("general", "enabled", true).set(enabled);
        config.get("general", "serverHost", "localhost").set(serverHost);
        config.get("general", "serverPort", 17653).set(serverPort);

        config.save();
    }
}
